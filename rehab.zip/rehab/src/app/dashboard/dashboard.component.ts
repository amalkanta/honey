import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  tlSelectedMonth:any;
  totalLessonsMonthList:any=["January","February","March","April"];
  nlSelectedMonth:any;
  newLessonsMonthList:any=["January","February","March","April"];
  theMonthOfList:any=["January","February","March","April"];
  theMonthOfSelected:any;
  
  constructor() { }

  ngOnInit(): void {
    this.tlSelectedMonth=this.totalLessonsMonthList[0];
    this.nlSelectedMonth=this.newLessonsMonthList[0];
    this.theMonthOfSelected=this.theMonthOfDropdownSel[0];
  }
  tlDropdownSel($event){
    alert($event);
  }
  nlDropdownSel($event){
    alert($event);
  }
  theMonthOfDropdownSel($event){
    alert($event);
  }

}
