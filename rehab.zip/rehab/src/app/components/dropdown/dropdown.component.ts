import { Component, OnInit, Input, Output } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent implements OnInit {

  @Input() inputLists:any;
  @Input() selected:any;
  @Output() onDropdownSelect =new Subject();


  constructor() { }

  ngOnInit(): void {
    if(this.selected ==="" || this.selected===undefined || this.selected === null){
      this.selected=this.inputLists[0];
    }
  }
  onOptionsSelected() {
    this.onDropdownSelect.next(this.selected);
   }
  

}
