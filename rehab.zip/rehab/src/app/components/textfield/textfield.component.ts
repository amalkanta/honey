import { Component, OnInit, Input, Self, Optional, ViewChild, ElementRef } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';

@Component({
  selector: 'app-textfield',
  templateUrl: './textfield.component.html',
  styleUrls: ['./textfield.component.scss']
})
export class TextfieldComponent implements OnInit, ControlValueAccessor {

  value:any="";

  constructor(
    @Self()
    @Optional()
    private ngControl: NgControl
  ) {
    if (this.ngControl) {
      this.ngControl.valueAccessor = this;
    }
  }

  ngOnInit(): void {
  }
  @Input() label:string;
  @Input() type:string;
  @Input() placeholder:string;
  @Input() disabled:boolean;

  @ViewChild("input") inputRef : ElementRef
  isFocus:boolean=false;
  inputText:string="";


  onInputFocus(){
    this.isFocus = true;
    this.inputRef.nativeElement.focus()
  }

  onInputBlur(){
    this.isFocus = false
     if(this.inputText!=""){
      this.isFocus = true
    }

  }
  onInputChange(e){
    this.inputText = e;
    this.isFocus = true
  }
  writeValue(value: any): void {
    this.value = value;
  }

  /**
   * Write form disabled state to the DOM element (model => view)
   */
  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  /**
   * Update form when DOM element value changes (view => model)
   */
  registerOnChange(fn: any): void {
    // Store the provided function as an internal method.
    this.onInputChange = fn;
  }

  /**
   * Update form when DOM element is blurred (view => model)
   */
  registerOnTouched(fn: any): void {
    // Store the provided function as an internal method.
    this.onInputBlur = fn;
  }
}
