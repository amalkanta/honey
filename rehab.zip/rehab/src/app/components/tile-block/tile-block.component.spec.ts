import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TileBlockComponent } from './tile-block.component';

describe('TileBlockComponent', () => {
  let component: TileBlockComponent;
  let fixture: ComponentFixture<TileBlockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TileBlockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TileBlockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
